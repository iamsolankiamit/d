#! /bin/sh

VIDEOPATH="/home/pi/arrow/media"
SERVICE="omxplayer"
while true; do
	if ps ax | grep -v grep | grep $SERVICE > /dev/null
	then
	sleep 1;
else
	for entry in $VIDEOPATH/*
	do
		clear
		omxplayer --hdmi --no-osd --win "0 0 1475 826" $entry > /dev/null
	done
fi
done