import httplib
import time
import urllib2
import urllib
import json
import requests
import pexpect
import fileinput
import threading
import subprocess
import sys
import wget
import psutil
import os

SERVER_URL = "http://192.168.1.118"
SERVER_PORT = "3000"
MEDIA_FOLDER = "./arrow/media/"
NOT_CONNECTED_FILE = "/home/pi/arrow/static/notconnected.html"
NOT_REGISTERED_FILE = "/home/pi/arrow/static/notregistered.html"
GROUP_NOT_ASSIGNED_FILE = "/home/pi/arrow/static/nogroup.html"
PLAYLIST_NOT_ASSIGNED_FILE = "/home/pi/arrow/static/noplaylist.html"
DOWNLOADING_FILE = "/home/pi/arrow/static/downloading.html"
NO_DESIGN_FILE = "/home/pi/arrow/static/nodesign.html"
NOT_CONNECTED_BROWSER_OPEN = False
NOT_REGISTERED_BROWSER_OPEN = False
GROUP_NOT_ASSIGNED_BROWSER_OPEN = False
NO_DESIGN_BROWSER_OPEN = False
execute_flag = True
layout = "a"

def do_every (interval, worker_func, iterations = 0):
  if iterations != 1:
    threading.Timer (
      interval,
      do_every, [interval, worker_func, 0 if iterations == 0 else iterations-1]
    ).start()
  worker_func()

def open_browser(file_path):
  link = "iceweasel --profile=fullscreen --url %s" % (file_path)
  iceweasel = subprocess.Popen(link, shell=True)

def update_local_file(jsondata,json_slot):
  print "updating local file"
  jsonFile = open("data.json", "r")
  data = json.load(jsonFile)
  jsonFile.close()
  print "opening data.json file"
  if json_slot == "pi":
    tmp = data["pi"]
    data["pi"] = jsondata["pis"][0]
    print "update pi stuff"
  elif json_slot == "group":
    print "update group stuff"
    tmp = data["group"]
    data["group"] = jsondata["group"]
  elif json_slot == "playlist":
    tmp = data["playlist"]
    data["playlist"] = jsondata["playlist"]
    print "update playlist stuff"
  jsonFile = open("data.json", "w+")
  jsonFile.write(json.dumps(data))
  jsonFile.close()
  print "Closing data.json file"

def kill_all_process():
  print "THIS IS SPARTAAAAAA!!!!!!!!!!!!!!!!!!!"
  layout_name = "%s.sh" % (layout)
  for proc in psutil.process_iter():
    # check whether the process name matches
    if proc.name() == layout_name:
        proc.kill()
        print "killed Omx loop"
    if proc.name() == "iceweasel":
        proc.kill()
        print "killed iceweasel"
    if proc.name() == "omxplayer":
        proc.kill()
        print "killed omx"

def delete_videos():
  print "deleted Folders"
  fileList = os.listdir(MEDIA_FOLDER)
  for fileName in fileList:
    os.remove(MEDIA_FOLDER+"/"+fileName)
  # layoutFileList = os.listdir(layoutFolder)
  # for fileName in layoutFileList:
  #   os.remove(layoutFolder+"/"+fileName)
  # # remove media folder content
  # remove layout folder content
  print "removed video content"

def read_local_file():
  with open('data.json') as data_file:
    global data
    data = json.load(data_file)

def update_videos():
  for video_url in playlist["playlist"]["videos"]:   
        print video_url["movie_url"]
        movie_url = "%s:%s%s" % (SERVER_URL,SERVER_PORT,video_url["movie_url"])
        path = "%s%s" % (MEDIA_FOLDER,video_url["movie_file_name"])
        wget.download(movie_url, path)

def execute():
  print "Executing ......"
  kill_all_process()
  if execute_flag:
    if layout == "a":
      omxplayer = subprocess.Popen("./a.sh", shell=True)
      link = "iceweasel --profile=fullscreen --url %s:%s/designs/%s" % (SERVER_URL,SERVER_PORT,design["design"]["id"])
      iceweasel = subprocess.Popen(link,shell=True)
      print link
    elif layout == "b":
      omxplayer = subprocess.Popen("./b.sh",shell=True)
    elif layout == "c":
      omxplayer = subprocess.Popen("./c.sh",shell=True)
      link = "iceweasel --profile=fullscreen --url %s:%s/designs/%s" % (SERVER_URL,SERVER_PORT,design["design"]["id"])
      iceweasel = subprocess.Popen(link,shell=True)
      print link
    elif layout == "d":
      omxplayer = subprocess.Popen("./d.sh",shell=True)
      link = "iceweasel --profile=fullscreen --url %s:%s/designs/%s" % (SERVER_URL,SERVER_PORT,design["design"]["id"])
      iceweasel = subprocess.Popen(link,shell=True)
      print link
    elif layout == "e":
      link = "iceweasel --profile=fullscreen --url %s:%s/designs/%s" % (SERVER_URL,SERVER_PORT,design["design"]["id"])
      iceweasel = subprocess.Popen(link,shell=True)
      print link

def get_design():
  read_local_file()
  design_id = playlist["playlist"]["design_id"]
  if design_id != None:
    u = "%s:%s/designs/%s.json" % (SERVER_URL,SERVER_PORT,design_id)
    response = requests.get(u)
    global design
    design = response.json()
    print design
    global layout
    layout = design["design"]["layout_type"]
  else:
    if no_design_browser_open == False:
      open_browser(NO_DESIGN_FILE)
      no_design_browser_open = True

def get_playlist():
  read_local_file()  
  playlist_id = group["group"]["playlist_id"]
  if playlist_id != None:
    u = "%s:%s/playlists/%s.json" % (SERVER_URL,SERVER_PORT,playlist_id)
    response = requests.get(u)
    global playlist
    playlist = response.json()
    print playlist
    version = data["playlist"]["version"]
    if playlist["playlist"]["id"] == data["playlist"]["id"]:
      if playlist["playlist"]["version"] > data["playlist"]["version"]:
        kill_all_process()
        open_browser(DOWNLOADING_FILE)
        delete_videos()
        update_videos()
        execute_flag = True
        update_local_file(playlist, "playlist")
        kill_all_process()
        get_design()
        execute()
      else:
        get_design()
        execute()
    else:
      print "boo"
      kill_all_process()
      open_browser(DOWNLOADING_FILE)
      delete_videos()
      update_videos()
      execute_flag = True
      update_local_file(playlist, "playlist")
      kill_all_process()
      get_design()
      execute()
  else:
    if playlist_not_assigned_browser_open == False:
      open_browser(PLAYLIST_NOT_ASSIGNED_FILE)
      playlist_not_assigned_browser_open = True
      print "No Playlist assigned to the group."


def check_group():
  read_local_file()
  group_id = data["pi"]["group_id"]
  print group_id
  if group_id != None:
    u = "%s:%s/groups/%s.json" % (SERVER_URL,SERVER_PORT,str(group_id))
    response = requests.get(u)
    global group
    group = response.json()
    print group
    updated_at = data["group"]["updated_at"]
    count = data["group"]["count"]
    if data["group"]["id"] == group["group"]["id"]:
      if group["group"]["count"] > data["group"]["count"]: #time.strptime(group["updated_at"], "%d %b %y") > time.strptime(updated_at, "%d %b %y"):
        get_playlist()
        update_local_file(group, "group")
      else:
        print "No Need to update. Already Updated"
        get_playlist()
    else:
      update_local_file(group, "group")
      get_playlist()
  else:
    if group_not_assigned_browser_open == False:
      open_browser(GROUP_NOT_ASSIGNED_FILE)
      group_not_assigned_browser_open = True
      print "group Not registered"

def check_registration():
  read_local_file()
  global data
  pi_uuid = data["pi"]["uid"]
  u = "%s:%s/pis.json?uuid=%s" % (SERVER_URL,SERVER_PORT,pi_uuid)
  response = requests.get(u)
  if response.status_code == 200: # check header for success info
    pi = response.json()
    print pi
    update_local_file(pi, "pi")
    check_group()
  else:
    global NOT_REGISTERED_BROWSER_OPEN
    if NOT_REGISTERED_BROWSER_OPEN == False:
      open_browser(NOT_REGISTERED_FILE)
      NOT_REGISTERED_BROWSER_OPEN = True

def ping_status():
  print "checking ping status"
  response = os.system("sudo ping -c 1 -w2 " + SERVER_URL)
  if response:
    print "Checking Registration"
    check_registration()
  else:
    print "Not Connected Opening Browser with Current status, Ip, and Registration no."
    # TODO: if disconnected after starting then what?
    if NOT_CONNECTED_BROWSER_OPEN == False: # If browser is already open don't open another.
      open_browser(NOT_CONNECTED_FILE)
      not_connected_browser_open = True

do_every(600,ping_status)
